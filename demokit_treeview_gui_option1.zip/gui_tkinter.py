import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from modules import hypertext_parser

class DemoKitGUI(tk.Tk):
    def __init__(self, processor):
        super().__init__()
        self.processor = processor
        self.title("Engelbart Journal")
        self.geometry("1100x650")

        # Sidebar with Treeview
        sidebar_frame = tk.Frame(self)
        sidebar_frame.pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        self.sidebar = ttk.Treeview(sidebar_frame, columns=('ID', 'Title', 'Description'), show='headings', height=25)
        self.sidebar.heading('ID', text='ID')
        self.sidebar.heading('Title', text='Title')
        self.sidebar.heading('Description', text='Description')
        self.sidebar.column('ID', width=60, anchor='center')
        self.sidebar.column('Title', width=220, anchor='w')
        self.sidebar.column('Description', width=480, anchor='w')
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)

        sb = tk.Scrollbar(sidebar_frame, orient=tk.VERTICAL, command=self.sidebar.yview)
        sb.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.config(yscrollcommand=sb.set)
        self.sidebar.bind("<<TreeviewSelect>>", self._on_select)

        # Main text widget
        main_frame = tk.Frame(self)
        main_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.text = tk.Text(main_frame, wrap="word", cursor="xterm")
        self.text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.text.bind("<Button-3>", self.show_context_menu)

        # Button frame
        button_frame = tk.Frame(main_frame)
        button_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=4)
        self.ask_button = tk.Button(button_frame, text="ASK", command=self.handle_ask)
        self.ask_button.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.back_button = tk.Button(button_frame, text="BACK", command=self.go_back)
        self.back_button.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="ASK", command=self.handle_ask)
        self.context_menu.add_command(label="Import Document", command=self.import_document)
        self.context_menu.add_command(label="Export Document", command=self.export_document)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Quit", command=self.quit)

        # Populate sidebar
        self.refresh_sidebar()

    def refresh_sidebar(self):
        self.sidebar.delete(*self.sidebar.get_children())
        docs = self.processor.doc_store.get_document_index()
        for doc in docs:
            self.sidebar.insert('', 'end', values=(doc['id'], doc['title'], doc['description']))

    def _on_select(self, event):
        selected = self.sidebar.selection()
        if selected:
            item = self.sidebar.item(selected[0])
            doc_id = item['values'][0]
            doc = self.processor.doc_store.get_document(doc_id)
            if doc:
                self.text.delete('1.0', tk.END)
                self.text.insert(tk.END, doc['body'])
                if hasattr(hypertext_parser, "parse_links"):
                    hypertext_parser.parse_links(self.text, doc['body'], self.open_doc_by_id)
                self.text.edit_reset()

    def open_doc_by_id(self, doc_id):
        doc = self.processor.doc_store.get_document(doc_id)
        if doc:
            self.text.delete('1.0', tk.END)
            self.text.insert(tk.END, doc['body'])
            if hasattr(hypertext_parser, "parse_links"):
                hypertext_parser.parse_links(self.text, doc['body'], self.open_doc_by_id)
            self.text.edit_reset()

    def show_context_menu(self, event):
        self.context_menu.tk_popup(event.x_root, event.y_root)

    def handle_ask(self):
        pass  # Implement ASK behavior

    def go_back(self):
        pass  # Implement BACK behavior

    def import_document(self):
        pass

    def export_document(self):
        pass