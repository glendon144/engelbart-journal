
import tkinter as tk
import re
import webbrowser
from tkinter import simpledialog, messagebox
from modules import hypertext_parser

class DemoKitGUI(tk.Tk):
    """Main Tkinter GUI for the DemoKit journal workspace."""

    _link_pattern = re.compile(r'\[([^\]]+)\]\(doc:(\d+)\)')

    # ------------------------------------------------------------------ #
    #  Construction
    # ------------------------------------------------------------------ #
    def __init__(self, processor):
        super().__init__()                 # do NOT pass processor to Tk
        self.processor = processor
        self.title("DemoKit Journal Workspace")
        self.geometry("1000x600")
        self.history = []

        # --- sidebar -------------------------------------------------- #
        self.sidebar = tk.Listbox(self, width=40)
        # keyboard shortcuts for sidebar
        self.sidebar.bind("<Return>",  lambda e: self._sidebar_edit())
        self.sidebar.bind("<Delete>",  lambda e: self._sidebar_delete())
        self.sidebar.bind("<BackSpace>", lambda e: self._sidebar_delete())

        # control buttons under sidebar
        btn_frame = tk.Frame(self)
        btn_frame.pack(side=tk.LEFT, fill=tk.X, padx=4, pady=4)

        tk.Button(btn_frame, text="Edit", width=6,
                  command=self._sidebar_edit).pack(side=tk.TOP, fill=tk.X, pady=(0,4))
        tk.Button(btn_frame, text="Delete", width=6,
                  command=self._sidebar_delete).pack(side=tk.TOP, fill=tk.X)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.bind("<<ListboxSelect>>", self._on_select)
        # sidebar context menu
        self.sidebar_menu = tk.Menu(self, tearoff=0)
        self.sidebar_menu.add_command(label="Edit", command=self._sidebar_edit)
        self.sidebar_menu.add_command(label="Delete", command=self._sidebar_delete)
        self.sidebar.bind("<Button-3>", self._show_sidebar_menu)

        # --- back button ---------------------------------------------- #
        self.back_button = tk.Button(self, text="Back", command=self.go_back)
        self.back_button.pack(side=tk.BOTTOM, fill=tk.X)

        # --- editor --------------------------------------------------- #
        self.text_editor = tk.Text(self, wrap=tk.WORD)
        self.text_editor.pack(expand=True, fill=tk.BOTH)

        # context‑menu
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="ASK AI + Link", command=self.ask_ai_autolink)
        self.text_editor.bind("<Button-3>", self._show_ctx)

        # initial load
        # --- sidebar control buttons and global key bindings ---
        btn_frame = tk.Frame(self)
        btn_frame.pack(side=tk.LEFT, anchor='n', padx=4, pady=4)

        tk.Button(btn_frame, text="Edit", width=8,
                  command=self._sidebar_edit).pack(fill=tk.X, pady=(0,4))
        tk.Button(btn_frame, text="Delete", width=8,
                  command=self._sidebar_delete).pack(fill=tk.X)

        # global keyboard shortcuts
        self.bind_all("<Delete>", lambda e: self._sidebar_delete())
        self.bind_all("<BackSpace>", lambda e: self._sidebar_delete())
        self.bind_all("<Return>", lambda e: self._sidebar_edit())
        self._refresh_sidebar()

    # ------------------------------------------------------------------ #
    #  Sidebar helpers
    # ------------------------------------------------------------------ #
    def _refresh_sidebar(self):
        self.sidebar.delete(0, tk.END)
        self.docs = self.processor.doc_store.list_documents()
        for _, row in self.docs.iterrows():
            self.sidebar.insert(tk.END, f"{row['doc_id']}: {row['title']}")

    def _on_select(self, _event):
        sel = self.sidebar.curselection()
        if not sel:
            return
        doc_id = int(str(self.sidebar.get(sel[0])).split(":")[0])
        self.open_document(doc_id, remember=True)

    # ------------------------------------------------------------------ #
    #  Document navigation
    # ------------------------------------------------------------------ #
    def open_document(self, doc_id, remember=False):
        """Load document *doc_id* into the editor."""
        if remember:
            self.history.append(getattr(self, 'current_doc_id', None))
        self.current_doc_id = doc_id
        body = self.processor.view_document(doc_id)
        self._display_body(body)

    def go_back(self):
        if not self.history:
            return
        prev = self.history.pop()
        if prev is None:
            return
        self.open_document(prev, remember=False)

    # ------------------------------------------------------------------ #
    #  Display helpers
    # ------------------------------------------------------------------ #
    def _display_body(self, body):
        """Show *body* in the Text widget and style links."""
        self.text_editor.config(state="normal")
        self.text_editor.delete("1.0", tk.END)
        self.text_editor.insert("1.0", body)
        self._render_links()
        self.text_editor.config(state="normal")

    def _render_links(self):
        """Convert [label](doc:N) markup in the widget into clickable tags."""
        body = self.text_editor.get("1.0", "end-1c")
        plain, links = hypertext_parser.strip_and_extract_links(body)

        # Replace widget text with plain version
        self.text_editor.delete("1.0", "end")
        self.text_editor.insert("1.0", plain)

        # Clear previous link tags
        for tag in self.text_editor.tag_names():
            if tag.startswith("link-"):
                self.text_editor.tag_delete(tag)

        # Apply new tags
        for i, (start, end, doc_id) in enumerate(links):
            tag = f"link-{i}"
            idx1 = f"1.0+{start}c"
            idx2 = f"1.0+{end}c"
            self.text_editor.tag_add(tag, idx1, idx2)
            self.text_editor.tag_config(tag, foreground="blue", underline=1)
            self.text_editor.tag_bind(tag, "<Enter>",
                                      lambda e: self.text_editor.config(cursor="hand2"))
            self.text_editor.tag_bind(tag, "<Leave>",
                                      lambda e: self.text_editor.config(cursor=""))
            # capture doc_id default arg
            self.text_editor.tag_bind(
                tag, "<Button-1>",
                lambda e, did=doc_id: self.open_document(did, remember=True)
            )

    # ------------------------------------------------------------------ #
    #  Context‑menu actions
    # ------------------------------------------------------------------ #
    def _show_ctx(self, event):
        self.menu.post(event.x_root, event.y_root)

    def ask_ai_autolink(self):
        try:
            selected = self.text_editor.selection_get().strip()
        except tk.TclError:
            messagebox.showwarning("No selection", "Please select text first.")
            return

        # optional user prompt
        prompt = simpledialog.askstring("ASK AI", "Enter optional question or context:")
        query = (prompt + " " if prompt else "") + selected
        response = self.processor.ai.ask(query)

        # create new document
        new_id = self.processor.doc_store.new_document(
            f"AI Response to: {selected}", response)

        # insert markdown link at selection
        link_markup = f"[{selected}](doc:{new_id})"
        self.text_editor.replace(tk.SEL_FIRST, tk.SEL_LAST, link_markup)

        # save back to document store
        body = self.text_editor.get("1.0", "end-1c")
        self.processor.doc_store.edit_document(self.current_doc_id, body)

        # re-render links and refresh sidebar
        self._render_links()
        self._refresh_sidebar()

        messagebox.showinfo("AI Response", f"AI response saved to Document {new_id}.")

    # ---------------- sidebar context‑menu callbacks ---------------- #

    def _on_sidebar_rclick(self, event):

        idx = self.sidebar.nearest(event.y)

        if idx < 0:

            return

        self.sidebar.selection_clear(0, tk.END)

        self.sidebar.selection_set(idx)

        self.sidebar.activate(idx)

        try:

            self.sidebar_menu.tk_popup(event.x_root, event.y_root)

        finally:

            self.sidebar_menu.grab_release()


    def _sidebar_edit(self):

        sel = self.sidebar.curselection()

        if not sel:

            return

        doc_id = int(str(self.sidebar.get(sel[0])).split(":")[0])

        self.open_document(doc_id, remember=True)


    def _sidebar_delete(self):

        sel = self.sidebar.curselection()

        if not sel:

            return

        doc_id = int(str(self.sidebar.get(sel[0])).split(":")[0])

        if messagebox.askyesno("Delete Document", f"Delete document {doc_id}?"):

            self.processor.doc_store.delete_document(doc_id)

            if getattr(self, 'current_doc_id', None) == doc_id:

                self.text_editor.delete("1.0", tk.END)

            self._refresh_sidebar()

