class CommandProcessor:
    def __init__(self, doc_store, ai, log):
        self.doc_store = doc_store
        self.ai = ai
        self.log = log

    def execute(self, command, *args):
        if command == "LIST":
            return self.doc_store.list_documents()
        elif command == "LOAD":
            return self.doc_store.get_document(*args)
        elif command == "SAVE":
            return self.doc_store.save_document(*args)
        elif command == "LINK":
            return self.doc_store.link_documents(*args)
        else:
            return "Unknown command"

    def query_ai(self, prompt):
        try:
            print(f"[INFO] Querying AI with: {prompt}")
            return self.ai.ask(prompt)
        except Exception as e:
            print(f"[ERROR] AI query failed: {e}")
            return f"Error: {e}"
