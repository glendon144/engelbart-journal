import pandas as pd
import os
from modules import hypertext_parser

valid_commands = ["GRAPH"]

class CommandProcessor:
    def __init__(self, doc_store, event_logger):
        self.doc_store = doc_store
        self.logger = event_logger

    def process(self, user_input):
        parts = user_input.split()
        if not parts:
            return

        cmd = parts[0].upper()

        if cmd == 'GRAPH':
            self.generate_graph()

        else:
            print(f"Unknown command: {cmd}")
            print("Valid commands are:", ", ".join(valid_commands))

    def generate_graph(self):
        df = self.doc_store.df
        edges = []
        for _, row in df.iterrows():
            doc_id = row['doc_id']
            title = row['title']
            body = row['body']
            links = hypertext_parser.extract_links_with_titles(str(body))
            for link_title, target_id in links:
                edges.append((doc_id, title, int(target_id), link_title))

        if not edges:
            print("No hyperlinks found in documents.")
            return

        print("Hypertext Network:")
        for src_id, src_title, tgt_id, link_title in edges:
            print(f"[{src_id}:{src_title}] --> [{tgt_id}] via '{link_title}'")

        pd.DataFrame(edges, columns=["SourceID", "SourceTitle", "TargetID", "LinkTitle"]).to_csv("graph.csv", index=False)
        print("\nGraph exported to 'graph.csv'")
