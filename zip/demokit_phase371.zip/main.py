import sys
import readline
from modules import document_store, logger, commands

def main():
    print("Welcome to DemoKit Phase 3.7.1 — User-Friendly Command Help")
    doc_store = document_store.DocumentStore("storage/documents.csv")
    event_logger = logger.EventLogger("storage/event_log.csv")
    cmd_processor = commands.CommandProcessor(doc_store, event_logger)

    while True:
        try:
            user_input = input("> ").strip()
            if user_input.lower() in ['exit', 'quit']:
                break
            cmd_processor.process(user_input)
        except EOFError:
            break

if __name__ == "__main__":
    main()
