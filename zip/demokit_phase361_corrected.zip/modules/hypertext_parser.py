import re

def extract_links(body):
    pattern = r"\[.*?\]\(doc:(\d+)\)"
    return re.findall(pattern, body)
