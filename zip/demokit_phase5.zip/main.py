print("Phase 5 Core environment initialized. Visualization module ready.") 
