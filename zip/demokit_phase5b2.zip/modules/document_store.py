import pandas as pd
import os

class DocumentStore:
    def __init__(self, filename):
        self.filename = filename
        self.columns = ['doc_id', 'title', 'body']
        if not os.path.exists(self.filename):
            pd.DataFrame(columns=self.columns).to_csv(self.filename, index=False)

    def load(self):
        return pd.read_csv(self.filename)

    def save(self, df):
        df.to_csv(self.filename, index=False)

    def new_document(self, title):
        df = self.load()
        doc_id = df['doc_id'].max() + 1 if not df.empty else 1
        new_row = pd.DataFrame([[doc_id, title, ""]], columns=self.columns)
        df = pd.concat([df, new_row], ignore_index=True)
        self.save(df)
        return doc_id

    def get_document(self, doc_id):
        df = self.load()
        return df[df['doc_id'] == doc_id]

    def edit_document(self, doc_id, new_body):
        df = self.load()
        df.loc[df['doc_id'] == doc_id, 'body'] = new_body
        self.save(df)

    def list_documents(self):
        df = self.load()
        return df[['doc_id', 'title']]
