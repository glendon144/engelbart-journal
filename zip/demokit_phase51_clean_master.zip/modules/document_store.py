import pandas as pd
import os
from datetime import datetime

class DocumentStore:
    def __init__(self, file_path):
        self.file_path = file_path
        if os.path.exists(file_path):
            self.df = pd.read_csv(file_path)
        else:
            self.df = pd.DataFrame(columns=['doc_id', 'title', 'body', 'created', 'last_modified'])
            self.df.to_csv(self.file_path, index=False)

    def save(self):
        self.df.to_csv(self.file_path, index=False)

    def new_document(self, title):
        doc_id = self._generate_id()
        now = datetime.now()
        self.df = pd.concat([self.df, pd.DataFrame([{
            'doc_id': doc_id,
            'title': title,
            'body': '',
            'created': now,
            'last_modified': now
        }])], ignore_index=True)
        self.save()
        return doc_id

    def edit_document(self, doc_id, new_body):
        self.df.loc[self.df['doc_id'] == doc_id, 'body'] = new_body
        self.df.loc[self.df['doc_id'] == doc_id, 'last_modified'] = datetime.now()
        self.save()

    def list_documents(self):
        return self.df[['doc_id', 'title']]

    def get_document(self, doc_id):
        return self.df[self.df['doc_id'] == doc_id]

    def _generate_id(self):
        if self.df.empty:
            return 1
        return int(self.df['doc_id'].max()) + 1
