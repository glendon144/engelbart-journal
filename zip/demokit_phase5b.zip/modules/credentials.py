import json
import os

class FacebookCredentials:
    def __init__(self, filepath="credentials/fb_credentials.json"):
        self.filepath = filepath
        self.token = None
        self.page_id = None
        self.load_credentials()

    def load_credentials(self):
        if os.path.exists(self.filepath):
            with open(self.filepath, "r") as f:
                data = json.load(f)
                self.token = data.get("access_token")
                self.page_id = data.get("page_id")

    def save_credentials(self, token, page_id):
        data = {
            "access_token": token,
            "page_id": page_id
        }
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        with open(self.filepath, "w") as f:
            json.dump(data, f)
        self.token = token
        self.page_id = page_id

    def is_configured(self):
        return self.token is not None and self.page_id is not None
