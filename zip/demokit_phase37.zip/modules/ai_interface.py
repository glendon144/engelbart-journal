import openai

class AIInterface:
    def __init__(self, api_key):
        openai.api_key = api_key

    def ask(self, query):
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": query}],
            temperature=0.7,
            max_tokens=500
        )
        return response.choices[0].message['content']
