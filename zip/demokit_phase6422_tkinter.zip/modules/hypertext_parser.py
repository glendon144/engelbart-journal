
import re

class HypertextParser:
    def extract_links(self, text):
        matches = re.findall(r"\[\[(.*?)\|(doc:(\d+))\]\]", text)
        return [{"text": m[0], "target": int(m[1].split(":")[1])} for m in matches]
