
class CommandProcessor:
    def __init__(self, doc_store, ai, log):
        self.doc_store = doc_store
        self.ai = ai
        self.log = log

    def list_documents(self):
        return self.doc_store.list_documents()

    def view_document(self, doc_id):
        return self.doc_store.get_document(doc_id)

    def edit_document(self, doc_id, new_body):
        self.doc_store.edit_document(doc_id, new_body)

    def ai_ask(self, query):
        return self.ai.ask(query)
