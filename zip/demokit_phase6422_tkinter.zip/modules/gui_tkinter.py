
import tkinter as tk
from tkinter import messagebox, simpledialog
from modules.hypertext_parser import HypertextParser

class DemoKitGUI:
    def __init__(self, processor):
        self.processor = processor
        self.parser = HypertextParser()
        self.root = tk.Tk()
        self.root.title("DemoKit Phase 6.4.2 — Live Sidebar Refresh Kernel")
        self.root.geometry("1100x700")
        self.history_stack = []

        self.doc_listbox = tk.Listbox(self.root, width=40)
        self.doc_listbox.pack(side=tk.LEFT, fill=tk.Y)

        self.text_editor = tk.Text(self.root)
        self.text_editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.text_editor.tag_config("link", foreground="blue", underline=1)
        self.text_editor.tag_bind("link", "<Button-1>", self.follow_link)

        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.save_button = tk.Button(self.button_frame, text="Save Changes", command=self.save_document)
        self.save_button.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.back_button = tk.Button(self.button_frame, text="Back", command=self.go_back)
        self.back_button.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.doc_listbox.bind('<<ListboxSelect>>', self.load_selected_document)
        self.text_editor.bind("<Button-3>", self.show_context_menu)

        self.load_documents()

    def load_documents(self):
        self.doc_listbox.delete(0, tk.END)
        df = self.processor.list_documents()
        for _, row in df.iterrows():
            self.doc_listbox.insert(tk.END, f"{row['doc_id']}: {row['title']}")

    def load_selected_document(self, event):
        selection = self.doc_listbox.curselection()
        if not selection:
            return
        item = self.doc_listbox.get(selection[0])
        doc_id = int(item.split(":")[0])
        self.load_document_by_id(doc_id, push_history=True)

    def display_body_with_links(self, body):
        self.text_editor.delete("1.0", tk.END)
        self.text_editor.insert(tk.END, body)
        links = self.parser.extract_links(body)
        for link in links:
            start = self.text_editor.search(link['text'], "1.0", stopindex=tk.END)
            if start:
                end = f"{start}+{len(link['text'])}c"
                self.text_editor.tag_add("link", start, end)
                self.text_editor.tag_bind("link", "<Enter>", lambda e: e.widget.config(cursor="hand2"))
                self.text_editor.tag_bind("link", "<Leave>", lambda e: e.widget.config(cursor=""))
                self.text_editor.tag_add(f"target_{link['target']}", start, end)

    def follow_link(self, event):
        index = self.text_editor.index(f"@{event.x},{event.y}")
        for tag in self.text_editor.tag_names(index):
            if tag.startswith("target_"):
                target_id = int(tag.split("_")[1])
                self.load_document_by_id(target_id, push_history=True)
                break

    def load_document_by_id(self, doc_id, push_history=False):
        if hasattr(self, 'current_doc_id') and push_history:
            self.history_stack.append(self.current_doc_id)
        self.current_doc_id = doc_id
        body = self.processor.view_document(doc_id)
        self.display_body_with_links(body)

    def go_back(self):
        if self.history_stack:
            prev_doc_id = self.history_stack.pop()
            self.load_document_by_id(prev_doc_id)
        else:
            messagebox.showinfo("Back", "No previous document.")

    def save_document(self):
        new_body = self.text_editor.get("1.0", tk.END).strip()
        self.processor.edit_document(self.current_doc_id, new_body)
        messagebox.showinfo("Saved", f"Document {self.current_doc_id} updated.")
        self.display_body_with_links(new_body)

    def show_context_menu(self, event):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Create Link", command=self.create_link)
        menu.add_command(label="ASK AI (Link Result)", command=self.ask_ai_autolink)
        menu.post(event.x_root, event.y_root)

    def create_link(self):
        try:
            selected_text = self.text_editor.selection_get()
            doc_id = simpledialog.askinteger("Link Target", "Enter doc_id:")
            if doc_id:
                link_markup = f"[[{selected_text}|doc:{doc_id}]]"
                self.text_editor.delete(tk.SEL_FIRST, tk.SEL_LAST)
                self.text_editor.insert(tk.SEL_FIRST, link_markup)
                self.display_body_with_links(self.text_editor.get("1.0", tk.END))
        except tk.TclError:
            messagebox.showwarning("No selection", "Please select text first.")

    def ask_ai_autolink(self):
        try:
            selected_text = self.text_editor.selection_get()
        except tk.TclError:
            messagebox.showwarning("No selection", "Please select text first.")
            return

        question = simpledialog.askstring("ASK AI", "Enter optional question or context:")
        query = (question + " " if question else "") + selected_text
        response = self.processor.ai.ask(query)
        new_doc_id = self.processor.doc_store.new_document(f"AI Response to: {selected_text}", response)
        link_markup = f"[[{selected_text}|doc:{new_doc_id}]]"
        self.text_editor.delete(tk.SEL_FIRST, tk.SEL_LAST)
        self.text_editor.insert(tk.SEL_FIRST, link_markup)
        self.display_body_with_links(self.text_editor.get("1.0", tk.END))
        messagebox.showinfo("AI Response", f"AI response saved to Document {new_doc_id}.")
        self.load_documents()


    def ask_ai_autolink(self):
        try:
            selected_text = self.text_editor.selection_get()
        except tk.TclError:
            messagebox.showwarning("No selection", "Please select text first.")
            return

        question = simpledialog.askstring("ASK AI", "Enter optional question or context:")
        query = (question + " " if question else "") + selected_text
        response = self.processor.ai.ask(query)
        new_doc_id = self.processor.doc_store.new_document(f"AI Response to: {selected_text}", response)

        # Instead of deleting, insert link markup wrapping selection
        self.text_editor.insert(tk.SEL_FIRST, f"[[")
        self.text_editor.insert(tk.SEL_LAST, f"|doc:{new_doc_id}]]")
        self.display_body_with_links(self.text_editor.get("1.0", tk.END))

        messagebox.showinfo("AI Response", f"AI response saved to Document {new_doc_id}.")
        self.load_documents()

    def run(self):
        self.root.mainloop()
