import sys
from modules import document_store, logger, commands

def main():
    print("Welcome to DemoKit Phase 3.6.2 - Robust Append Mode")
    doc_store = document_store.DocumentStore("storage/documents.csv")
    event_logger = logger.EventLogger("storage/event_log.csv")
    cmd_processor = commands.CommandProcessor(doc_store, event_logger)

    while True:
        user_input = input("> ").strip()
        if user_input.lower() in ['exit', 'quit']:
            break
        cmd_processor.process(user_input)

if __name__ == "__main__":
    main()
