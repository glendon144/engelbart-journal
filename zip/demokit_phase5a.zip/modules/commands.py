import pandas as pd
import os
from modules import network_visualizer

valid_commands = ["NEW", "LIST", "VIEW", "EDIT", "VISUALIZE"]

class CommandProcessor:
    def __init__(self, doc_store):
        self.doc_store = doc_store

    def process(self, user_input):
        parts = user_input.split()
        if not parts:
            return

        cmd = parts[0].upper()

        if cmd == 'NEW':
            title = ' '.join(parts[1:])
            doc_id = self.doc_store.new_document(title)
            print(f"Document {doc_id} created.")

        elif cmd == 'LIST':
            print(self.doc_store.list_documents())

        elif cmd == 'VIEW':
            if len(parts) < 2:
                print("Usage: VIEW <doc_id>")
                return
            doc_id = int(parts[1])
            doc = self.doc_store.get_document(doc_id)
            if doc.empty:
                print("Document not found.")
            else:
                print(doc.iloc[0]['body'])

        elif cmd == 'EDIT':
            if len(parts) < 2:
                print("Usage: EDIT <doc_id>")
                return
            doc_id = int(parts[1])
            existing_body = self.doc_store.get_document(doc_id).iloc[0]['body']
            existing_body = existing_body if pd.notnull(existing_body) else ""
            new_body = input("Enter text to append:\n")
            combined_body = existing_body + "\n" + new_body
            self.doc_store.edit_document(doc_id, combined_body)
            print(f"Document {doc_id} updated (appended).")

        elif cmd == 'VISUALIZE':
            viz = network_visualizer.HypertextVisualizer(self.doc_store)
            filename = viz.visualize()
            print(f"Hypertext graph generated: {filename}")

        else:
            print(f"Unknown command: {cmd}")
            print("Valid commands are: " + ", ".join(valid_commands))
