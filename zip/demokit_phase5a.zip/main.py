import sys
import readline
from modules import document_store, commands

def main():
    print("Welcome to DemoKit Phase 5A — Credentials Integration Build")
    doc_store = document_store.DocumentStore("storage/documents.csv")
    cmd_processor = commands.CommandProcessor(doc_store)

    while True:
        try:
            user_input = input("> ").strip()
            if user_input.lower() in ['exit', 'quit']:
                break
            cmd_processor.process(user_input)
        except EOFError:
            break

if __name__ == "__main__":
    main()
