
import openai
import os

class AIInterface:
    def __init__(self):
        self.api_key_path = "credentials/openai_key.txt"
        self._load_key()

    def _load_key(self):
        if os.path.exists(self.api_key_path):
            with open(self.api_key_path) as f:
                openai.api_key = f.read().strip()

    def ask(self, prompt):
        self._load_key()
        if not openai.api_key:
            return "No OpenAI API key loaded."
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
