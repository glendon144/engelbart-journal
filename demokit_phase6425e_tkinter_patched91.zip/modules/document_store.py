
import pandas as pd
import os

class DocumentStore:
    def __init__(self, storage_path):
        self.storage_path = storage_path
        self._ensure_storage()

    def _ensure_storage(self):
        if not os.path.exists(self.storage_path):
            df = pd.DataFrame(columns=["doc_id", "title", "body"])
            df.to_csv(self.storage_path, index=False)

    def list_documents(self):
        df = pd.read_csv(self.storage_path)
        return df.fillna("")

    def get_document(self, doc_id):
        df = pd.read_csv(self.storage_path)
        doc = df[df["doc_id"] == doc_id]
        if doc.empty:
            return ""
        return doc.iloc[0]["body"]

    def new_document(self, title, body):
        df = pd.read_csv(self.storage_path)
        doc_id = 1 if df.empty else df["doc_id"].max() + 1
        df = df.append({"doc_id": doc_id, "title": title, "body": body}, ignore_index=True)
        df.to_csv(self.storage_path, index=False)
        return doc_id

    def edit_document(self, doc_id, new_body):
        df = pd.read_csv(self.storage_path)
        df.loc[df["doc_id"] == doc_id, "body"] = new_body
        df.to_csv(self.storage_path, index=False)


def update_document(self, doc_id, body):
    """Backwards‑compat wrapper for GUI; calls edit_document."""
    return self.edit_document(doc_id, body)
