
import re

def extract_links(body):
    pattern = r"\[([^\]]+)\]\(doc:(\d+)\)"
    matches = re.findall(pattern, body)
    return [(text, int(doc_id)) for text, doc_id in matches]


import re

link_pattern = re.compile(r'\[([^\]]+)\]\(doc:(\d+)\)')

def strip_and_extract_links(text):
    """Return (plain_text, links) where links is list of (start, end, doc_id)."""
    parts = []
    links = []
    last = 0
    for m in link_pattern.finditer(text):
        parts.append(text[last:m.start()])
        label, doc_id = m.groups()
        start_idx = sum(len(p) for p in parts)
        parts.append(label)
        end_idx = start_idx + len(label)
        links.append((start_idx, end_idx, int(doc_id)))
        last = m.end()
    parts.append(text[last:])
    plain_text = "".join(parts)
    return plain_text, links
