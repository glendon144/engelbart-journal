
import pandas as pd
import os
from datetime import datetime

class Logger:
    def __init__(self, log_path="logs/log.csv"):
        self.log_path = log_path
        self._ensure_log()

    def _ensure_log(self):
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        if not os.path.exists(self.log_path):
            df = pd.DataFrame(columns=["timestamp", "user", "action", "target", "details"])
            df.to_csv(self.log_path, index=False)

    def log(self, user, action, target, details):
        df = pd.read_csv(self.log_path)
        df = df.append({
            "timestamp": datetime.now().isoformat(),
            "user": user,
            "action": action,
            "target": target,
            "details": details
        }, ignore_index=True)
        df.to_csv(self.log_path, index=False)
