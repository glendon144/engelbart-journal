
import tkinter as tk
import re
import webbrowser
from tkinter import simpledialog, messagebox
from modules import hypertext_parser

class DemoKitGUI(tk.Tk):


    _link_pattern = re.compile(r'\[([^\]]+)\]\(doc:(\d+)\)')


    def _render_links(self):

        """Scan the Text widget, style any [label](doc:N) spans, make them clickable."""

        body = self.text_editor.get("1.0", "end-1c")


        # clear previous link tags

        for tag in self.text_editor.tag_names():

            if tag.startswith("link-"):

                self.text_editor.tag_delete(tag)


        for match in self._link_pattern.finditer(body):

            label, doc_id = match.groups()

            label_start = match.start() + 1              # skip leading '['

            label_end   = label_start + len(label)


            idx1 = f"1.0+{label_start}c"

            idx2 = f"1.0+{label_end}c"


            tag = f"link-{label_start}"

            self.text_editor.tag_add(tag, idx1, idx2)

            self.text_editor.tag_config(tag, foreground="blue", underline=1)

            self.text_editor.tag_bind(tag, "<Enter>",

                                       lambda e: self.text_editor.config(cursor="hand2"))

            self.text_editor.tag_bind(tag, "<Leave>",

                                       lambda e: self.text_editor.config(cursor=""))

            self.text_editor.tag_bind(tag, "<Button-1>",

                                       lambda e, did=int(doc_id): self.open_document(did))

    """END_PARSE_FUNC_MARKER"""

    def __init__(self, processor):
        super().__init__()
        self.processor = processor
        self.title("DemoKit Journal Workspace")
        self.geometry("1000x600")
        self.history = []

        self.sidebar = tk.Listbox(self, width=40)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.bind("<<ListboxSelect>>", self.load_selected_document)

        self.back_button = tk.Button(self, text="Back", command=self.go_back)
        self.back_button.pack(side=tk.BOTTOM, fill=tk.X)

        self.text_editor = tk.Text(self, wrap=tk.WORD)
        self.text_editor.pack(expand=True, fill=tk.BOTH)

        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="ASK AI + Link", command=self.ask_ai_autolink)
        self.text_editor.bind("<Button-3>", self.show_context_menu)

        self.text_editor.tag_config("link", foreground="blue", underline=1)
        self.text_editor.tag_bind("link", "<Button-1>", self.follow_link)

        self.load_documents()

    def load_documents(self):
        self.sidebar.delete(0, tk.END)
        self.docs = self.processor.doc_store.list_documents()
        for _, row in self.docs.iterrows():
            self.sidebar.insert(tk.END, f"{row['doc_id']}: {row['title']}")

    def load_selected_document(self, event):
        selection = self.sidebar.curselection()
        if not selection:
            return
        index = selection[0]
        doc_id = int(str(self.sidebar.get(index)).split(":")[0])
        self.history.append(getattr(self, 'current_doc_id', None))
        self.current_doc_id = doc_id
        body = self.processor.view_document(doc_id)
        self.display_body_with_links(body)

    def display_body_with_links(self, body):
        self.text_editor.delete("1.0", tk.END)
        self.text_editor.insert(tk.END, body)
        links = hypertext_parser.extract_links(body)
        for link_text, target_id in links:
            start = "1.0"
            while True:
                pos = self.text_editor.search(f"[[{link_text}|doc:{target_id}]]", start, stopindex=tk.END)
                if not pos:
                    break
                end = f"{pos}+{len(link_text)+len(str(target_id))+9}c"
                self.text_editor.tag_add("link", pos, end)
                self.text_editor.tag_bind("link", "<Enter>", lambda e: self.text_editor.config(cursor="hand2"))
                self.text_editor.tag_bind("link", "<Leave>", lambda e: self.text_editor.config(cursor=""))
                start = end

    def show_context_menu(self, event):
        self.menu.post(event.x_root, event.y_root)

    def ask_ai_autolink(self):
        try:
            selected_text = self.text_editor.selection_get().strip()
        except tk.TclError:
            messagebox.showwarning("No selection", "Please select text first.")
            return

        question = simpledialog.askstring("ASK AI", "Enter optional question or context:")
        query = (question + " " if question else "") + selected_text
        response = self.processor.ai.ask(query)
        new_doc_id = self.processor.doc_store.new_document(f"AI Response to: {selected_text}", response)

        link_markup = f"[{selected_text}](doc:{new_doc_id})"
        self.text_editor.replace(tk.SEL_FIRST, tk.SEL_LAST, link_markup)
        body = self.text_editor.get("1.0", tk.END).strip()
        self.processor.doc_store.edit_document(self.current_doc_id, body)
        self.text_editor.delete("1.0", tk.END)
        self.text_editor.insert(tk.END, body)
        self.display_body_with_links(body)
        messagebox.showinfo("AI Response", f"AI response saved to Document {new_doc_id}.")
        self.load_documents()
            self._render_links()

    def follow_link(self, event):
        index = self.text_editor.index("@%s,%s" % (event.x, event.y))
        for tag in self.text_editor.tag_names(index):
            if tag == "link":
                content = self.text_editor.get("1.0", tk.END)
                links = hypertext_parser.extract_links(content)
                for link_text, target_id in links:
                    if f"[[{link_text}|doc:{target_id}]]" in content:
                        self.history.append(self.current_doc_id)
                        self.current_doc_id = int(target_id)
                        body = self.processor.view_document(target_id)
                        self.display_body_with_links(body)
                        return

    def go_back(self):
        if not self.history:
            return
        prev_doc_id = self.history.pop()
        if prev_doc_id is None:
            return
        self.current_doc_id = prev_doc_id
        body = self.processor.view_document(prev_doc_id)
        self.display_body_with_links(body)
