import tkinter as tk
from tkinter import messagebox, simpledialog
from tkinter import ttk
from modules.document_store import DocumentStore

class DemoKitGUI(tk.Tk):
    def __init__(self, processor):
        super().__init__()
        self.title("DemoKit")
        self.geometry("1000x600")
        self.processor = processor

        self.sidebar = tk.Listbox(self, width=30)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)

        self.text = tk.Text(self, wrap=tk.WORD)
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.ask_button = tk.Button(self, text="Ask", command=self.ask_ai_text)
        self.ask_button.pack(side=tk.BOTTOM)

        self.sidebar.bind("<Button-3>", self._show_sidebar_menu)
        self._refresh_sidebar()

    def _refresh_sidebar(self):
        self.sidebar.delete(0, tk.END)
        self.docs = self.processor.doc_store.list_documents()
        for doc_id, title in self.docs:
            self.sidebar.insert(tk.END, f"{doc_id}: {title}")
        self.sidebar.bind("<<ListboxSelect>>", self._on_sidebar_select)

    def _on_sidebar_select(self, event):
        selection = self.sidebar.curselection()
        if selection:
            index = selection[0]
            doc_id, _ = self.docs[index]
            try:
                content = self.processor.doc_store.get_document_body(doc_id)
                self.text.delete(1.0, tk.END)
                self.text.insert(tk.END, content)
            except Exception as e:
                self.text.delete(1.0, tk.END)
                self.text.insert(tk.END, f"Error loading document content: {e}")

    def _show_sidebar_menu(self, event):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="ASK", command=self.ask_ai_text)
        menu.add_command(label="LINK", command=self.link_ai_context)
        menu.add_command(label="SAVE", command=self.save_current_document)
        menu.tk_popup(event.x_root, event.y_root)

    def ask_ai_text(self):
        selected_text = self.text.get(tk.SEL_FIRST, tk.SEL_LAST) if self.text.tag_ranges(tk.SEL) else self.text.get(1.0, tk.END)
        response = self.processor.ask(selected_text.strip())
        self.text.insert(tk.END, f"\n\n[AI Response]: {response}")

    def link_ai_context(self):
        selected_text = self.text.get(tk.SEL_FIRST, tk.SEL_LAST) if self.text.tag_ranges(tk.SEL) else ""
        context = self.text.get(1.0, tk.END).strip()
        linked = self.processor.link(selected_text.strip(), context)
        self.text.insert(tk.END, f"\n\n[LINKED]: {linked}")

    def save_current_document(self):
        content = self.text.get(1.0, tk.END).strip()
        title = simpledialog.askstring("Title", "Enter a title for this document:")
        if title:
            new_id = self.processor.doc_store.new_document(title, content)
            self._refresh_sidebar()
            messagebox.showinfo("Saved", f"Document saved with ID {new_id}")

