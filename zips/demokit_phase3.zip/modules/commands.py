from modules import hypertext_parser, ai_interface

class CommandProcessor:
    def __init__(self, doc_store, event_logger):
        self.doc_store = doc_store
        self.logger = event_logger
        self.ai = None

    def process(self, user_input):
        parts = user_input.split()
        if not parts:
            return

        cmd = parts[0].upper()

        if cmd == 'NEW':
            title = ' '.join(parts[1:])
            doc_id = self.doc_store.new_document(title)
            self.logger.log('user', 'NEW', doc_id, title)
            print(f"Document {doc_id} created.")

        elif cmd == 'LIST':
            print(self.doc_store.list_documents())

        elif cmd == 'VIEW':
            if len(parts) < 2:
                print("Usage: VIEW <doc_id>")
                return
            doc_id = int(parts[1])
            doc = self.doc_store.get_document(doc_id)
            if doc.empty:
                print("Document not found.")
            else:
                print(doc.iloc[0]['body'])

        elif cmd == 'EDIT':
            if len(parts) < 2:
                print("Usage: EDIT <doc_id>")
                return
            doc_id = int(parts[1])
            new_body = input("Enter new body text:\n")
            self.doc_store.edit_document(doc_id, new_body)
            self.logger.log('user', 'EDIT', doc_id, '')
            print(f"Document {doc_id} updated.")

        elif cmd == 'LINKS':
            if len(parts) < 2:
                print("Usage: LINKS <doc_id>")
                return
            doc_id = int(parts[1])
            doc = self.doc_store.get_document(doc_id)
            if doc.empty:
                print("Document not found.")
            else:
                body = doc.iloc[0]['body']
                links = hypertext_parser.extract_links(body)
                if links:
                    print("Links found:", links)
                else:
                    print("No links found.")

        elif cmd == 'FOLLOW':
            if len(parts) < 2:
                print("Usage: FOLLOW <doc_id>")
                return
            target_doc = int(parts[1])
            doc = self.doc_store.get_document(target_doc)
            if doc.empty:
                print("Target document not found.")
            else:
                print(doc.iloc[0]['body'])
                self.logger.log('user', 'FOLLOW', target_doc, '')

        elif cmd == 'LOG':
            print(self.logger.df.tail(10))

        elif cmd == 'SETKEY':
            if len(parts) < 2:
                print("Usage: SETKEY <OpenAI-API-Key>")
                return
            self.ai = ai_interface.AIInterface(parts[1])
            print("OpenAI API Key set.")

        elif cmd == 'ASK':
            if self.ai is None:
                print("Please set API key first using SETKEY.")
                return
            query = ' '.join(parts[1:])
            response = self.ai.ask(query)
            self.logger.log('user', 'ASK', '', query)
            print(response)

        else:
            print("Unknown command.")
