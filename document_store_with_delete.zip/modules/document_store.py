
import pandas as pd
import os

class DocumentStore:
    def __init__(self, storage_path):
        self.storage_path = storage_path
        self._ensure_storage()

    # ---------------- internal helpers -------------------------- #
    def _ensure_storage(self):
        if not os.path.exists(self.storage_path):
            df = pd.DataFrame(columns=["doc_id", "title", "body"])
            df.to_csv(self.storage_path, index=False)

    def _read(self):
        return pd.read_csv(self.storage_path)

    def _write(self, df):
        df.to_csv(self.storage_path, index=False)

    # ---------------- public API -------------------------------- #
    def list_documents(self):
        return self._read().fillna("")

    def get_document(self, doc_id):
        df = self._read()
        doc = df[df["doc_id"] == doc_id]
        return "" if doc.empty else doc.iloc[0]["body"]

    def new_document(self, title, body):
        df = self._read()
        doc_id = 1 if df.empty else df["doc_id"].max() + 1
        df = df.append({"doc_id": doc_id, "title": title, "body": body},
                       ignore_index=True)
        self._write(df)
        return doc_id

    def edit_document(self, doc_id, new_body):
        df = self._read()
        if doc_id not in df["doc_id"].values:
            return False
        df.loc[df["doc_id"] == doc_id, "body"] = new_body
        self._write(df)
        return True

    # ---- NEW: delete routine for GUI --------------------------- #
    def delete_document(self, doc_id):
        """Remove *doc_id* from the CSV store. Returns True if removed."""
        df = self._read()
        if doc_id not in df["doc_id"].values:
            return False
        df = df[df["doc_id"] != doc_id]
        self._write(df)
        return True

    # ---- Backwards‑compat alias used by older GUI -------------- #
    def update_document(self, doc_id, body):
        return self.edit_document(doc_id, body)
