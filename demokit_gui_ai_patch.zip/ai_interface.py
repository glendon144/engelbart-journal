import openai
from modules.logger import Logger


class AIInterface:
    """Thin wrapper around the OpenAI ChatCompletion endpoint."""

    def __init__(self, logger=None):
        self.api_key = None
        self.logger = logger or Logger()

    # ---------------------------------------------------------------- api key
    def set_api_key(self, key: str):
        self.api_key = key
        openai.api_key = key
        self.logger.info("OpenAI API key set.")

    # ---------------------------------------------------------------- query
    def query(self, prompt: str) -> str:
        if not self.api_key:
            raise RuntimeError("API key not set")
        self.logger.debug(f"Querying OpenAI: {prompt[:80]}…")
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
            )
            reply = response["choices"][0]["message"]["content"].strip()
            self.logger.debug("AI query successful")
            return reply
        except Exception as exc:
            self.logger.error(f"AI query failed: {exc}")
            raise