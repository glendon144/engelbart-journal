import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from modules import hypertext_parser

class DemoKitGUI(tk.Tk):
    def __init__(self, doc_store, processor):
        super().__init__()
        self.doc_store = doc_store
        self.processor = processor

        self.title("Engelbart Journal")
        self.geometry("1100x650")

        print("DEBUG: Initializing DemoKitGUI window...")

        # Sidebar with Treeview
        sidebar_frame = tk.Frame(self, bg="orange")  # Highlight the sidebar frame!
        sidebar_frame.pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        self.sidebar = ttk.Treeview(
            sidebar_frame, columns=('ID', 'Title', 'Description'),
            show='headings', height=25
        )
        self.sidebar.heading('ID', text='ID')
        self.sidebar.heading('Title', text='Title')
        self.sidebar.heading('Description', text='Description')
        self.sidebar.column('ID', width=60, anchor='center')
        self.sidebar.column('Title', width=220, anchor='w')
        self.sidebar.column('Description', width=480, anchor='w')
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        print("DEBUG: Sidebar Treeview packed.")

        sb = tk.Scrollbar(sidebar_frame, orient=tk.VERTICAL, command=self.sidebar.yview)
        sb.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.config(yscrollcommand=sb.set)
        self.sidebar.bind("<<TreeviewSelect>>", self._on_select)

        # Main text widget
        main_frame = tk.Frame(self, bg="lightblue")
        main_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.text = tk.Text(main_frame, wrap="word", cursor="xterm")
        self.text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.text.bind("<Button-3>", self.show_context_menu)
        print("DEBUG: Main text area packed.")

        # Button frame
        button_frame = tk.Frame(main_frame, bg="yellow")
        button_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=4)
        self.ask_button = tk.Button(button_frame, text="ASK", command=self.handle_ask)
        self.ask_button.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.back_button = tk.Button(button_frame, text="BACK", command=self.go_back)
        self.back_button.pack(side=tk.LEFT, fill=tk.X, expand=True)
        print("DEBUG: Button frame packed.")

        # Context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="ASK", command=self.handle_ask)
        self.context_menu.add_command(label="Import Document", command=self.import_document)
        self.context_menu.add_command(label="Export Document", command=self.export_document)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Quit", command=self.quit)

        # Populate sidebar
        self.refresh_sidebar()

    def refresh_sidebar(self):
        print("DEBUG: Entering refresh_sidebar...")
        self.sidebar.delete(*self.sidebar.get_children())

        # Test row to ensure the Treeview is visible and working!
        print("DEBUG: Inserting test row.")
        self.sidebar.insert('', 'end', values=("TEST", "Hello World", "If you see this, Treeview is working!"))

        docs = self.doc_store.get_document_index()
        print("DEBUG: docs from get_document_index():", docs)
        for doc in docs:
            print("INSERTING TO SIDEBAR:", doc['id'], doc['title'], doc['description'])
            self.sidebar.insert('', 'end', values=(doc['id'], doc['title'], doc['description']))

    def _on_select(self, event):
        print("DEBUG: Sidebar selection event triggered.")
        selected = self.sidebar.selection()
        if selected:
            item = self.sidebar.item(selected[0])
            doc_id = item['values'][0]
            print(f"DEBUG: Selected doc_id: {doc_id}")
            doc = self.doc_store.get_document(doc_id)
            if doc:
                self.text.delete('1.0', tk.END)
                self.text.insert(tk.END, doc['body'])
                if hasattr(hypertext_parser, "parse_links"):
                    hypertext_parser.parse_links(self.text, doc['body'], self.open_doc_by_id)
                self.text.edit_reset()

    def open_doc_by_id(self, doc_id):
        print(f"DEBUG: open_doc_by_id called with doc_id: {doc_id}")
        doc = self.doc_store.get_document(doc_id)
        if doc:
            self.text.delete('1.0', tk.END)
            self.text.insert(tk.END, doc['body'])
            if hasattr(hypertext_parser, "parse_links"):
                hypertext_parser.parse_links(self.text, doc['body'], self.open_doc_by_id)
            self.text.edit_reset()

    def show_context_menu(self, event):
        self.context_menu.tk_popup(event.x_root, event.y_root)

    def handle_ask(self):
        print("DEBUG: ASK button clicked.")
        pass  # Implement ASK behavior

    def go_back(self):
        print("DEBUG: BACK button clicked.")
        pass  # Implement BACK behavior

    def import_document(self):
        print("DEBUG: Import Document selected.")
        pass

    def export_document(self):
        print("DEBUG: Export Document selected.")
        pass

