import openai
from modules.logger import Logger
from modules.document_store import DocumentStore

class CommandProcessor:
    def __init__(self, store: DocumentStore, ai_interface, logger=None):
        self.doc_store = store
        self.ai = ai_interface
        self.logger = logger if logger else Logger()

    def ask_question(self, prompt: str) -> str:
        """
        Send a standalone prompt to the AI and return its response.
        """
        try:
            self.logger.info(f"Sending standalone prompt to AI: {prompt}")
            response = self.ai.query(prompt)
            self.logger.info("AI response received successfully")
            return response
        except Exception as e:
            self.logger.error(f"AI query failed: {e}")
            return None

    def query_ai(self, selected_text: str, current_doc_id: int,
                 on_success, on_link_created, prefix: str = None):
        """
        1) Builds a prompt from selected_text (with optional prefix)
        2) Queries the AI
        3) Saves the reply as a new document
        4) Embeds a markdown link back to the new doc in the original document
        5) Invokes callbacks to update the GUI or CLI
        """
        # 1) Build prompt
        if prefix:
            prompt = f"{prefix} {selected_text}"
        else:
            prompt = f"Please expand on this: {selected_text}"
        self.logger.info(f"Sending prompt: {prompt}")

        # 2) Query AI
        try:
            reply = self.ai.query(prompt)
        except Exception as e:
            self.logger.error(f"AI query failed: {e}")
            return
        self.logger.info("AI query successful")

        # 3) Save reply as new document
        new_doc_id = self.doc_store.add_document("AI Response", reply)
        self.logger.info(f"Created new document {new_doc_id}")

        # 4) Embed markdown link in original document
        original = self.doc_store.get_document(current_doc_id)
        if original and selected_text in original.get("body", ""):
            updated_body = original["body"].replace(
                selected_text,
                f"[{selected_text}](doc:{new_doc_id})",
                1
            )
            self.doc_store.update_document(current_doc_id, updated_body)
            self.logger.info(
                f"Embedded link to document {new_doc_id} in document {current_doc_id}"
            )
        else:
            self.logger.info(
                f"Could not embed link: '{selected_text}' not found in document {current_doc_id}"
            )

        # 5) Trigger callbacks
        on_link_created()
        on_success(new_doc_id)

    def set_api_key(self, api_key: str):
        """
        Proxy setting of API key to underlying AIInterface.
        """
        try:
            self.ai.set_api_key(api_key)
            self.logger.info("API key successfully set in AI interface")
        except Exception as e:
            self.logger.error(f"Failed to set API key: {e}")

    def get_context_menu_actions(self) -> dict:
        """
        Return mappings for GUI context menu items, if any.
        """
        return {
            "Import CSV": self.doc_store.import_csv,
            "Export CSV": self.doc_store.export_csv
        }
