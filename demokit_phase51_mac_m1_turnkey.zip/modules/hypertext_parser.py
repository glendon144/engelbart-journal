import re

def extract_links(body):
    pattern = r"\[.*?\]\(doc:(\d+)\)"
    return re.findall(pattern, body)

def extract_links_with_titles(body):
    pattern = r"\[(.*?)\]\(doc:(\d+)\)"
    return re.findall(pattern, body)
